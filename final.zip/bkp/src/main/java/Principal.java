import java.util.Locale;
import java.util.Scanner;

public class Principal{

public static void main(String[] args) {
    Facil facil = new Facil();
    int cont=0;
    while (cont<=10) {

        facil.jogar();
        System.out.println(facil.getSelecao());
        System.out.println("Descubra qual é essa palavra --> " + facil.getSelecaoMisturada());
        Scanner entrada = new Scanner(System.in);
        facil.setRespostadoJogador(entrada.nextLine().toLowerCase());
        cont++;

     }
    System.out.println("Score: " + facil.getScore());
    System.out.println("Gabarito : " + facil.respostaCorreta.toString());
    System.out.println("Resposta do Jogador : " + facil.respostaInformadas.toString());
    }
}