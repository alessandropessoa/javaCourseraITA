public class Jogador{
    private int score;
    protected String  resposta;
    protected void responder(String resposta){
        //jogador sabe responder
        this.resposta = resposta;
    }

}