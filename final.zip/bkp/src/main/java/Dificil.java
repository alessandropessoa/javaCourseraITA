
public class Dificil extends BaseMecanicaDoJogo{

}