import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Stream;
import java.util.Random;

public class BancoDePalavras {

    private int numeroLinha = 60;
    private String palavraSelecionada;
    private String palavraSelecionadaMisturada;
    private String caminhoArquivo = "baseDeDadosPalavras.txt";
    protected Random numeroAleatorio = new Random();

    public BancoDePalavras() {
    }

    protected void setnumeroLinha(int nl) {
        //numero de linha que contem o arquivo é a mesma da quantidade de palavras
        // esse valor é o argumento do objeto Random, que retorna um valor aleatorio
        // correspondente a  palavra selecionada dentro do arquivo.
        this.numeroLinha = nl;
    }

    protected void setCaminhoArquivo(int caminho) {
        // recebe o caminho do arquivo
        this.caminhoArquivo = caminhoArquivo;
    }

    protected void palavraAleatoria() {
        // retorna palavra aleatoria de uma lista de arquivo texto
        //conforme o numero de linhas que é o mesmo que o numero de palavras de um determinado Path
        int selecao;
        selecao = numeroAleatorio.nextInt(numeroLinha);
        try (Stream<String> lines = Files.lines(Paths.get(caminhoArquivo))) {
            palavraSelecionada = lines.skip(selecao).findFirst().get();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    protected void misturadordePalavras() {
        List<String> letters = Arrays.asList(palavraSelecionada.split(""));
        Collections.shuffle(letters);
        StringBuilder aux = new StringBuilder(palavraSelecionada.length());
        for (String aux02 : letters) {
            aux.append(aux02);
        }
        this.palavraSelecionadaMisturada = aux.toString();
    }

    public String getPalavraSelecionada() { return palavraSelecionada;}

    public String getPalavraSelecionadaMisturada(){return palavraSelecionadaMisturada;}
}