import java.util.ArrayList;
import java.util.List;


public class Facil extends BaseMecanicaDoJogo{
    FabricaEmbaralhadores fmb = new FabricaEmbaralhadores();
    @Override
    public void jogar (){
        bp.palavraAleatoria(); //pega uma palavra aleatoria do arquivo
        this.selecao = bp.getPalavraSelecionada().replaceAll("^[ \t]+|[ \t]+$", "");
        this.respostaCorreta.add(this.selecao);

       //mistura a palavra encontrada
        //this.selecaoMisturada = fmb.embaralhadorAleatorio(this.selecao);
        this.selecaoMisturada = new  StringBuilder(this.selecao).reverse().toString();

    }

}