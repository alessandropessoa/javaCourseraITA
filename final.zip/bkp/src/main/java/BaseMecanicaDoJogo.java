import java.util.ArrayList;
import java.util.List;

abstract class BaseMecanicaDoJogo implements MecanicaDoJogoInterface {
    protected String respostadoJogador;
    protected String selecao;
    protected String selecaoMisturada;
    protected int score=0;
    public List<String> respostaInformadas =  new ArrayList<>();
    public List<String> respostaCorreta =  new ArrayList<>();

    protected BancoDePalavras bp = new BancoDePalavras();
    FabricaEmbaralhadores fmb = new FabricaEmbaralhadores();

    public void jogar (){
        bp.palavraAleatoria(); //pega uma palavra aleatoria do arquivo
        this.selecao = bp.getPalavraSelecionada().replaceAll("^[ \t]+|[ \t]+$", "");
        this.respostaCorreta.add(this.selecao);


        bp.misturadordePalavras(); //mistura a palavra encontrada

        this.selecaoMisturada = bp.getPalavraSelecionadaMisturada();

    }

    public void gabarito(){
        if(this.respostadoJogador.equals(this.selecao)){
            this.score+=10;
        }
    }

    public int getScore(){return this.score;}

    public void setRespostadoJogador(String resposta){
        this.respostadoJogador = resposta.replaceAll("^[ \t]+|[ \t]+$", "");
        this.respostaInformadas.add(resposta);
        this.gabarito();

    }
    public String getSelecao(){return this.selecao;}
    public String getSelecaoMisturada(){return this.selecaoMisturada;}

}