import java.util.Random;

public class FabricaEmbaralhadores{
    protected BancoDePalavras bp = new BancoDePalavras();
    protected Random embaralhadorAleatorio = new Random();
    int numeroEmbaralhadorAleatorio;
    String aux;

    public String embaralhador(String selecao){
        numeroEmbaralhadorAleatorio = embaralhadorAleatorio.nextInt(2);
        if (numeroEmbaralhadorAleatorio==1){
            this.embaralhadorSimples(String selecao);
        }else{
            this.embralhadorComplexo();
        }
        return this.aux;
    }

    private void embaralhadorSimples( String selecao){
        this.aux = new  StringBuilder(selecao).reverse().toString();

    }

    private  void embralhadorComplexo(){
        bp.misturadordePalavras(); //mistura a palavra encontrada
        this.aux =bp.getPalavraSelecionadaMisturada();

    }

}