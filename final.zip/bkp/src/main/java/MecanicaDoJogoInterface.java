public interface MecanicaDoJogoInterface{
    public void jogar ();
    public int getScore();
    public void gabarito();
}