//import  org.junit.After;
import org.junit.Test;
import  org.junit.AfterClass;
import java.util.Scanner;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class TesteFacil {


    @Test
    public void testar(){



    }
    @AfterClass
    public static void zeraTeste(){

    }
}