//import  org.junit.After;
import org.junit.Test;
import  org.junit.AfterClass;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class TesteBancoDePalavras {


    @Test
    public void testar(){
        BancoDePalavras bp = new BancoDePalavras();
        bp.palavraAleatoria();
        String prev = bp.getPalavraSelecionada();
        String next = bp.getPalavraSelecionada();
        assertNotEquals(prev, next);
    }
    @AfterClass
    public static void zeraTeste(){

    }
}