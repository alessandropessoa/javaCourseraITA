
public class Dificil extends BaseMecanicaDoJogo{
    public int peso = 2;
}