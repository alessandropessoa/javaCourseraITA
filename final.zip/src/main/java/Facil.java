import java.util.ArrayList;
import java.util.List;


public class Facil extends BaseMecanicaDoJogo{
    public int peso = 1;

}