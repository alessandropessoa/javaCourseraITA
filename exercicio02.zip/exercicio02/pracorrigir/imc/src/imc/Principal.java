package imc;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		
		double peso, altura;
		
		Scanner input = new Scanner( System.in );
				
		System.out.println("Vamos Calcular o seu IMC:");

		System.out.printf("Digite o seu peso: ");
		peso = Double.parseDouble(input.nextLine());
				
		System.out.printf("Digite a sua Altura: ");
		altura = Double.parseDouble(input.nextLine());
				
		Paciente pessoa = new Paciente(peso,altura);
		pessoa.diagnostico();

	}

}
