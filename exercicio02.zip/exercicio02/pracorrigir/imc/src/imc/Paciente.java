package imc;

import java.text.DecimalFormat;

public class Paciente {
	
	double peso;
	double altura;
	double imc;
	String resultado;
			
	public Paciente (double peso, double altura) {
		this.peso = peso;
		this.altura = altura;
	}
	
	DecimalFormat df = new DecimalFormat("###,##0.00");
	
		double calcularIMC () {
			return peso / (altura*altura);
	}
	
	public void diagnostico () {
		if (calcularIMC() < 16) {
			this.resultado = "Baixo Peso Muito Grave";
		} else if (calcularIMC() > 16 && calcularIMC() <17) {
			this.resultado = "Baixo Peso Grave";
		} else if (calcularIMC() >= 17 && calcularIMC() < 18.5) {
			this.resultado = "Baixo Peso";
		} else if (calcularIMC() >= 18.5 && calcularIMC() < 25) {
			this.resultado = "Peso Normal";
		} else if (calcularIMC() >= 25 && calcularIMC() < 30 ) {
			this.resultado = "Sobrepeso";
		} else if (calcularIMC() >= 30 && calcularIMC() < 35) {
			this.resultado = "Obesidade Grau I";
		} if (calcularIMC() >= 35 && calcularIMC() < 40) {
			this.resultado = "Obesidade Grau II";
		} else if(calcularIMC() >= 40) {
			this.resultado = "Obesidade Grau III (Obesidade M�rbida)";
		}
			System.out.println("Seu IMC �: "+df.format(calcularIMC())+" kg/m2, o que indica: "+this.resultado);
	}

	public Object getResultado() {
		// TODO Auto-generated method stub
		return this.resultado;
	}
}
	

	
