import java.util.Scanner;


public class Paciente{
    double peso   = 0;
    double altura = 0;

    public Paciente (double peso, double altura){
        this.peso   = peso;
        this.altura = altura;      
    }

    public double calcularIMC(){
        //calcula IMC
        double IMC;
        IMC = peso/(altura*altura);
        return IMC; 

    } 

    public void diagnostico(){
        //Diagnostico do paciente
        double imc;
        imc = calcularIMC();
 
        if (imc < 16){
            System.out.println("Baixo peso muito grave = IMC abaixo de 16 kg/m²");
        }

        else if ((16 >= imc) && (imc <= 16.99)){
            System.out.println("Baixo peso grave = IMC entre 16 e 16,99 kg/m²");
        }

        else if((17 >= imc) && (imc <= 1849)){
            System.out.println("Baixo peso = IMC entre 17 e 18,49 kg/m²");
        }

        else if( (18.50 >= imc)  && (imc <= 18.49)){
            System.out.println("Baixo peso = IMC entre 17 e 18,49 kg/m²");
        }

        else if((1850 >= imc) && (imc <= 2499)){
            System.out.println("Peso normal = IMC entre 18,50 e 24,99 kg/m²");
        }

        else if( (2500 >= imc)  && (imc<= 2999)){
            System.out.println("Sobrepeso = IMC entre 25 e 29,99 kg/m²");
            }

        else if((3000 >= imc)  && (imc<= 3499)){
            System.out.println("Obesidade grau I = IMC entre 30 e 34,99 kg/m²");
            }
        
        else if(( 3500 >= imc) && (imc <= 3999)){
            System.out.println("Obesidade grau II = IMC entre 35 e 39,99 kg/m²");
            }
        
        else if(imc >= 4000){
            System.out.println("Obesidade grau III (obesidade mórbida) = IMC igual ou maior que 40 kg/m²");
            }
        else{
            System.out.println("Valor imc: "+imc);
            System.out.println("Nenhuma das hipoteses! ");
        }
    }
    public static void main(String[] args){
        Paciente paciente = new Paciente(95,1.80);
        paciente.diagnostico();
        
        System.out.println("FIM!");
    }
}

