public class Carro{
 int potencia;
 int velocidade;
 String nome;

 void acelerar(){
  velocidade += potencia;
 }
 void frear(){
 velocidade /=2;
 }
 int getVeloc(){
  return velocidade;
 }
 void imprimir(){
  System.out.println("o carro"+nome+"esta a velocidade de"+getVeloc()+"km/h");
 }

}
