public class Principal{

 public static void main(String[] args){
  Carro c1 = new Carro();
  c1.potencia = 30;
  c1.nome="ferrari";
  c1.velocidade = 0;
  c1.imprimir();
 }
}
