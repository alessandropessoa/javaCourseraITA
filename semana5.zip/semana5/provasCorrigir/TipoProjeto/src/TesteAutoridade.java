import static org.junit.Assert.*;

import org.junit.Test;

public class TesteAutoridade {

	@Test
	public void testAutoridadeInformal() {
		// Apenas o nome
		Autoridade autoridade = new Autoridade("Roberto", "Campim", new Informal());
		assertEquals("Roberto", autoridade.getTratamento());
	}

	@Test
	public void testAutoridadeRespeitoso() {
		// Sra ou Sr e sobrenome
		Autoridade autoridade = new Autoridade("Temer", "Irra", new Respeitoso('M'));
		assertEquals("Sr Irra", autoridade.getTratamento());
	}

	@Test
	public void testAutoridadeComTitulo() {
		// Titulo antes do nome
		Autoridade autoridade = new Autoridade("Carlos", "Roberto", new ComTitulo("O Grande"));
		assertEquals("O Grande Carlos Roberto", autoridade.getTratamento());
	}

}
