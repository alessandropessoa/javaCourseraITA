public class Respeitoso implements FormatadorNome {
	private char sexo;

	public Respeitoso(char sexo) {
		this.sexo = sexo;
	}

	@Override
	public String formatadorNome(String nome, String sobrenome) {
		if (sexo == 'M') {
			return "Sr " + sobrenome;
		}else{
			return "Sra " + sobrenome;
		}
	}

}
