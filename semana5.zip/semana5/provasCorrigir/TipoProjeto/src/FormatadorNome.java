public interface FormatadorNome {

	// Vai receber nome e o sobrenome
	public String formatadorNome(String nome, String sobrenome);

}
