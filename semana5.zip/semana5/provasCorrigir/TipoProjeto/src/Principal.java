
public class Principal {

	public static void main(String[] args) {
		Informal informal = new Informal();
		System.out.println("Informal: " + informal.formatadorNome("Jailson", "Mendes"));

		Respeitoso respeitoso = new Respeitoso('F');
		System.out.println("Respeitoso: " + respeitoso.formatadorNome("Douglas", "DJ"));

		ComTitulo comtitulo = new ComTitulo("Sua Excelência Ilustríssima ");
		System.out.println("Com titulo: " + comtitulo.formatadorNome("Cidney", "J"));

	}

}
