public class Informal implements FormatadorNome {

	@Override
	public String formatadorNome(String nome, String sobrenome) {
		return nome;
	}

}
