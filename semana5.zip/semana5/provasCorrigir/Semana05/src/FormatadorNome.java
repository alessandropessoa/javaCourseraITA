
public interface FormatadorNome {
	public String formatarNome(String nome, String sobrenome);

}
