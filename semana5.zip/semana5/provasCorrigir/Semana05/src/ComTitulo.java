
public class ComTitulo implements FormatadorNome {
	
	private String titulo;
	
	public ComTitulo(String titulo){
		this.titulo = titulo;
	}

	public String formatarNome(String nome, String sobrenome) {
		// ComTítulo: deve receber em seu construtor o título e 
		//retornar o título seguido de nome e sobrenome. 
		//Exemplo: "Magnífico Pedro Cabral"
		return this.titulo + " " + nome + " " + sobrenome;
	}

}
