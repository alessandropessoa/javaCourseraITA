
public class Informal implements FormatadorNome {

	//public Informal(String nome, String sobrenome) {
		//super(nome, sobrenome);
	//}

	public String formatarNome(String nome, String sobrenome) {
		return nome;
	}

}
