
public class Autoridade {
	
	private String nome, sobrenome;
	FormatadorNome tratamento;
	
	public String getTratamento(){	
	    return tratamento.formatarNome(nome, sobrenome);
	}

	public Autoridade(String nome, String sobrenome,FormatadorNome obj) {
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.tratamento = obj;
	}

}
