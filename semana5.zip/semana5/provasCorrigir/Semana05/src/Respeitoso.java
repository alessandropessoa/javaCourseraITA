
public class Respeitoso implements FormatadorNome {
	private String sexo;
	public Respeitoso(String sexo){
		this.sexo = sexo;
	}

	public String formatarNome(String nome, String sobrenome) {
		//Respeitoso: deve receber em seu construtor a informação se é 
		//masculino ou feminino,
		//e retornar "Sr." ou "Sra." seguido do sobrenome
		String saida;
		if (this.sexo.equals("m")){
			saida = "Sr. " + sobrenome;
		}else {
			saida =" Sra. " + sobrenome;
		}
		
		return saida;
	}

}
