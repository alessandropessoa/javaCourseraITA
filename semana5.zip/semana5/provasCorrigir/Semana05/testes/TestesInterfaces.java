import static org.junit.Assert.*;

import org.junit.Test;


public class TestesInterfaces {

	@Test
	public void TestaInformal() {
		Autoridade obj = new Autoridade("Abutre", "Rossuga", new Informal());	
		assertEquals("Abutre", obj.getTratamento());
	}
	
	@Test
	public void TestaRespeitoso() {
		Autoridade obj2 = new Autoridade("Vulture", "Chapeu", new Respeitoso("m"));	
		assertEquals("Sr. Chapeu", obj2.getTratamento());
	}
	
	@Test
	public void TestaComTitulo() {
		Autoridade obj3 = new Autoridade("Doriana", "Fina", new ComTitulo("Doutora"));
		assertEquals("Doutora Doriana Fina", obj3.getTratamento());
	}

}
