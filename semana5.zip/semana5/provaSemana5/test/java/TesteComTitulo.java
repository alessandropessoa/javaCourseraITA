import org.junit.Assert;
import org.junit.Test;

class TesteComTitulo {
    @Test
    public void testarComTituloo(){
        Autoridade p1 = new Autoridade();
        p1.setNome("Alessandro");
        p1.setSobrenome("Pessoa");
        p1.setTitulo("Ilustrissimo");

        p1.getTratamento();

        String valorEsperado = "Ilustrissimo Alessandro Pessoa";

        Assert.assertEquals(valorEsperado,p1.toString());
    }
}