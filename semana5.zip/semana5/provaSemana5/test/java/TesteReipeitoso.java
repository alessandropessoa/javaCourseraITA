import org.junit.Assert;
import org.junit.Test;

class TesteRespeitoso {
    @Test
    public void testarRespeitoso(){
        Autoridade p1 = new Autoridade();
        p1.setNome("Alessandro");
        p1.setSobrenome("Pessoa");
        p1.setSexo("m");

        p1.getTratamento();

        String valorEsperado = "Sr. Alessandro Pessoa";

        Assert.assertEquals(valorEsperado,p1.toString());
    }
}