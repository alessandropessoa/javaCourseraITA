import org.junit.Assert;
import org.junit.Test;

public class TesteInformal {
    @Test
    public void testarInformal(){
        Autoridade p1 = new Autoridade();
        p1.setNome("Alessandro");
        p1.setSobrenome("Pessoa");

        p1.getTratamento();

        String valorEsperado = "Alessandro";

        Assert.assertEquals(valorEsperado,p1.toString());
    }
}