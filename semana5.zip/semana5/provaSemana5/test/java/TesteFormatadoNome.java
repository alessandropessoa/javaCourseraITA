import org.junit.Assert;
import org.junit.Test;

class TesteFormatadoNome {
    @Test
    public void testarFormatadoNome(){
        Autoridade p1 = new Autoridade();
        p1.setNome("Laura");
        p1.setSobrenome("Lavinia");

        Autoridade p2    = new Autoridade();
        p2.setNome("Gessica");
        p2.setSobrenome("Barreto");
        p2.setSexo("f");

        Autoridade p3    = new Autoridade();
        p3.setNome("Clara");
        p3.setSobrenome("Sophia");
        p3.setTitulo("Magnifico");

        p1.getTratamento();
        p2.getTratamento();
        p3.getTratamento();

        String valorEsperado1 = "Laura";
        String valorEsperado2 = "Sra. Gessica Barreto";
        String valorEsperado3 = "Magnifico Clara Sophia";

        Assert.assertEquals(valorEsperado1,p1.toString());
        Assert.assertEquals(valorEsperado2,p2.toString());
        Assert.assertEquals(valorEsperado3,p3.toString());
    }
}