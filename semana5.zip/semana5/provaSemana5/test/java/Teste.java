import org.junit.Test;

public class Teste {
    @Test
    public void main(){
        TesteInformal testeInformal = new TesteInformal();
        testeInformal.testarInformal();

        TesteRespeitoso testeRespeitoso = new TesteRespeitoso();
        testeRespeitoso.testarRespeitoso();

        TesteComTitulo testeComTitulo = new TesteComTitulo();
        testeComTitulo.testarComTituloo();

        TesteFormatadoNome testeFormatadoNome = new TesteFormatadoNome();
        testeFormatadoNome.testarFormatadoNome();


    }

}