public interface FormatadorNome {
    public void formatarNome();
}