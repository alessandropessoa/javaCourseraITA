public interface Respeitoso{
    public void Respeitoso(String titulo, String nome, String sobrenome);
}