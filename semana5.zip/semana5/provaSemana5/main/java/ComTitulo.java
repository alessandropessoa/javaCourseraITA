public interface ComTitulo {
    public void ComTitulo(String titulo,String nome, String sobrenome);
}