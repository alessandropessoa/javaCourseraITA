public interface Informal {
    public void  Informal(String nome, String sobrenome);
}