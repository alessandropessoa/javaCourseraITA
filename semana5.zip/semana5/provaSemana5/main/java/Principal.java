public class Principal {
    public static void main(String[] args){
        Autoridade p1 = new Autoridade();
        p1.setNome("Alessandro");
        p1.setSobrenome("Pessoa");

        Autoridade p2    = new Autoridade();
        p2.setNome("Gessica");
        p2.setSobrenome("Barreto");
        p2.setSexo("f");

        Autoridade p3    = new Autoridade();
        p3.setNome("Laura");
        p3.setSobrenome("Lavinia");
        p3.setTitulo("Magnifico");

        p1.getTratamento();
        p2.getTratamento();
        p3.getTratamento();

        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p3);
    }
}