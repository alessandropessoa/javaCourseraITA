public class Autoridade implements FormatadorNome,Informal,ComTitulo,Respeitoso{

    private String nome;
    private String sobrenome;
    private String sexo;
    private String titulo;
    private String aux;

    @Override
    public void ComTitulo(String titulo, String nome, String sobrenome) {
        String aux  = String.format("%s %s %s",titulo,nome,sobrenome);
        this.aux    = aux;
    }

    @Override
    public void Informal(String nome, String sobrenome) {
        String aux  = String.format("%s",nome);
        this.aux    = aux;
    }

    @Override
    public void Respeitoso(String sexo, String nome, String sobrenome) {
        String aux  = String.format("%s %s %s",sexo,nome,sobrenome);
        this.aux    = aux;
    }

    @Override
    public void formatarNome(){

        if(sexo!=null)
            Respeitoso(sexo,nome,sobrenome);
        else if(titulo!=null)
            ComTitulo(titulo,nome,sobrenome);
        else
            Informal(nome,sobrenome);
    }

    public void getTratamento(){
        formatarNome();
    }
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getSobrenome() {
        return sobrenome;
    }

    public void setSobrenome(String sobrenome) {
        this.sobrenome = sobrenome;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        if (sexo.toLowerCase().startsWith("m"))
            this.sexo = "Sr.";
        else
            this.sexo ="Sra.";
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
    @Override
    public String toString(){
        return  aux;
    }


}
